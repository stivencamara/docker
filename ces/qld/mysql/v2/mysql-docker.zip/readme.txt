https://dev.mysql.com/blog-archive/docker-compose-setup-for-innodb-cluster/
https://github.com/neumayer/mysql-docker-compose-examples/tree/master